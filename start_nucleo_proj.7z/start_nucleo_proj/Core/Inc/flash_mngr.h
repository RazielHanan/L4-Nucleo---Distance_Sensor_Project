#ifndef __FLASH_MNGR_H
#define __FLASH_MNGR_H

#include <stdint.h>
#include <stdbool.h>

#ifndef FLASH_BASE_USER_ADDR
#define FLASH_BASE_USER_ADDR   0x08080000U  // Start of Bank 2 user flash (safe zone)
#endif

#ifndef USER_FLASH_PAGE_SIZE
#define USER_FLASH_PAGE_SIZE        2048U        // STM32L476RG flash page size (2 KB)
#endif

#ifndef MAX_USER_FLASH_PAGES
#define MAX_USER_FLASH_PAGES        256           // (128KB / 2KB = 64 pages in Bank 2)
#endif
/**
 * Packed struct to store in flash
 */
typedef struct __attribute__((packed)) {
	/*
	 * you may change this struct according to your needs without change c file. see notes below.
	 */
    uint8_t  var1;
    uint8_t  var2;
    uint16_t var3;
    uint32_t var4;
    char     str[30];
    uint32_t crc32;  // IMPORTANT NOTE: KEEP IT AS THE LAST ITEM OF THE STRUCT
    				 // IMPORTANT NOTE: DO NOT WRITE TO CRC32 ITEM
} MyData_t;

/**
 * Write data to flash at the selected flash page (0 to MAX_FLASH_PAGES-1)
 * Returns true on success, false on failure
 */
bool write_to_flash(MyData_t data, uint8_t flash_page);

/**
 * Read data from flash at the selected flash page (0 to MAX_FLASH_PAGES-1)
 * Returns true if CRC is OK, false if corrupted
 */
bool read_from_flash(MyData_t* saved_data, uint8_t flash_page);

#endif // FLASH_MNGR_H
