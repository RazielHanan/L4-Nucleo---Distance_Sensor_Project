#ifndef __POWER_MODE_H
#define __POWER_MODE_H
#include "main.h"

#define BACKUP_REG_GET_IN_STOP_MODE   RTC_BKP_DR0

void shutdown_all_peripherals(void);
void wakeup_from_shutdown(void);
void init_peripherals(void);
#endif
