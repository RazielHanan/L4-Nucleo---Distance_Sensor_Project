#ifndef __GPIO_IT_HANDLER_H
#define __GPIO_IT_HANDLER_H
#include "main.h"




void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
uint32_t get_adc_value_mV(ADC_HandleTypeDef hadc);
uint32_t get_vrefint_mv(ADC_HandleTypeDef* hadc);
uint32_t read_internal_temp_mdegC(ADC_HandleTypeDef* hadc, uint32_t vrefint_mv);
#endif
