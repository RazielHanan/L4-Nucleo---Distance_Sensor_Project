#ifndef __GPIO_IT_HANDLER_H
#define __GPIO_IT_HANDLER_H
#include "stdint.h"
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);

#endif
