#ifndef __UART_HANDLER_H
#define __UART_HANDLER_H

#include <stdbool.h>

#ifndef UART_DMA_BUF_SIZE
#define UART_DMA_BUF_SIZE 128
#endif

typedef struct {
	uint8_t is_listening;
	uint8_t uart_dma_buf[UART_DMA_BUF_SIZE];
	uint16_t uart_dma_old_pos;
	uint32_t incoming_msgs;
	char message_buf[UART_DMA_BUF_SIZE];
} Uart_handler_args;

extern Uart_handler_args* uart2_args;

void init_uart_args();
void send_uart_message(UART_HandleTypeDef huart, char* msg_to_send); // tx uart message
void UART_DMA_Circular_Stop(UART_HandleTypeDef huart);
void UART_DMA_Circular_Start(UART_HandleTypeDef huart);
void UART_DMA_Check_IDLE(UART_HandleTypeDef *huart);
#endif
