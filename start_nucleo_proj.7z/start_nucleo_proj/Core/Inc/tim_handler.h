#ifndef __TIM_HANDLER_H
#define __TIM_HANDLER_H
#include "main.h"
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);

#endif
