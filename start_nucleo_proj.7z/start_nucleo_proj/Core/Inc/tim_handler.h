#ifndef __TIM_HANDLER_H
#define __TIM_HANDLER_H
#include "main.h"
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);
void send_single_pulse(TIM_HandleTypeDef htim,uint32_t TIM_CHANNEL);
void print_distance_with_tim(UART_HandleTypeDef huart);
#endif
