#include "flash_mngr.h"
#include "stm32l4xx_hal.h"
#include <string.h> // for memcpy

// Simple CRC32 (Polynomial 0x04C11DB7, same as STM32 hardware)
static uint32_t calculate_crc32(const uint8_t* data, size_t length) {
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < length; i++) {
        crc ^= ((uint32_t)data[i] << 24);
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x80000000)
                crc = (crc << 1) ^ 0x04C11DB7;
            else
                crc <<= 1;
        }
    }
    return crc ^ 0xFFFFFFFF;
}

bool write_to_flash(MyData_t data, uint8_t flash_page) {
    if (flash_page >= MAX_USER_FLASH_PAGES)
        return false;

    uint32_t flash_addr = FLASH_BASE_USER_ADDR + flash_page * USER_FLASH_PAGE_SIZE;

    // Compute CRC (excluding the CRC field itself)
    data.crc32 = calculate_crc32((uint8_t*)&data, sizeof(MyData_t) - sizeof(uint32_t));

    // Unlock Flash
    HAL_FLASH_Unlock();

    // Erase page
    FLASH_EraseInitTypeDef eraseInit;
    uint32_t pageError = 0;

    eraseInit.TypeErase = FLASH_TYPEERASE_PAGES;
    eraseInit.Banks = FLASH_BANK_2;
    eraseInit.Page = flash_page;
    eraseInit.NbPages = 1;

    if (HAL_FLASHEx_Erase(&eraseInit, &pageError) != HAL_OK) {
        HAL_FLASH_Lock();
        return false;
    }

    // Write struct in 64-bit chunks
    uint64_t* src = (uint64_t*)&data;
    size_t num_doublewords = (sizeof(MyData_t) + 7) / 8;

    for (size_t i = 0; i < num_doublewords; i++) {
        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, flash_addr + i * 8, src[i]) != HAL_OK) {
            HAL_FLASH_Lock();
            return false;
        }
    }

    HAL_FLASH_Lock();
    return true;
}

bool read_from_flash(MyData_t* saved_data, uint8_t flash_page) {
    if (flash_page >= MAX_USER_FLASH_PAGES)
        return false;

    uint32_t flash_addr = FLASH_BASE_USER_ADDR + flash_page * USER_FLASH_PAGE_SIZE;

    // Read raw data
    const MyData_t* stored = (const MyData_t*)flash_addr;
    memcpy(saved_data, stored, sizeof(MyData_t));

    // Recalculate CRC
    uint32_t expected_crc = calculate_crc32((uint8_t*)saved_data, sizeof(MyData_t) - sizeof(uint32_t));

    if (expected_crc == saved_data->crc32)
        return true;
    else
        return false;
}
