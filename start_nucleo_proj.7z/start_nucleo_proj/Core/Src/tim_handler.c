#include "tim_handler.h"
#include "uart_handler.h"
#include "main.h"


extern volatile uint32_t ic_val1;
extern volatile uint32_t ic_val2;
extern volatile uint8_t is_first_captured;
extern volatile uint32_t pulse_width_us;

void send_single_pulse(TIM_HandleTypeDef htim,uint32_t TIM_CHANNEL)
{
	HAL_TIM_PWM_Stop(&htim, TIM_CHANNEL);
	__HAL_TIM_SET_COUNTER(&htim, 0);  // Reset timer count
	HAL_TIM_PWM_Start(&htim, TIM_CHANNEL);  // Start one pulse
}

void print_distance_with_tim(UART_HandleTypeDef huart){
	if (pulse_width_us != 0) {
		char tim_str[45];
		uint8_t distance=0;
		distance = (pulse_width_us/2) / 29.1;
	    sprintf(tim_str,"Pulse duration = %lu us\r\nDistance = %u\r\n", pulse_width_us,distance);
	    send_uart_message(huart,tim_str);
	    pulse_width_us = 0; // reset for next
	}
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
    {
        if (is_first_captured == 0)
        {
        	ic_val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
            is_first_captured = 1;
            //__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
        }
        else if (is_first_captured == 1)
        {
            ic_val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
            uint32_t captured;
            if (ic_val2 > ic_val1)
                captured = ic_val2 - ic_val1;
            else
                captured = (0xFFFFFFFF - ic_val1) + ic_val2;

            pulse_width_us = (captured + 40) / 80; // round to nearest // Since 1 tick = 1 µs
            is_first_captured = 0;

            // Reset to rising edge to prepare for next pulse
            //__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
        }
    }
}
