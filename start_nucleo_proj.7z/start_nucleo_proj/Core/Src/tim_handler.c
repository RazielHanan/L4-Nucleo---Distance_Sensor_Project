#include "tim_handler.h"
#include "uart_handler.h"
#include "power_mode.h"
#include "main.h"


extern volatile uint32_t ic_val1;
extern volatile uint32_t ic_val2;
extern volatile uint8_t is_first_captured;
extern volatile uint32_t pulse_width_us;
extern UART_HandleTypeDef huart2;
extern RTC_HandleTypeDef hrtc;
extern volatile uint8_t get_in_stop_mode;
#ifndef MAX_TIMER_COUNT
#define MAX_TIMER_COUNT 65535
#endif
void send_single_pulse(TIM_HandleTypeDef htim,uint32_t TIM_CHANNEL)
{
	HAL_TIM_PWM_Stop(&htim, TIM_CHANNEL);
	__HAL_TIM_SET_COUNTER(&htim, 0);  // Reset timer count
	HAL_TIM_PWM_Start(&htim, TIM_CHANNEL);  // Start one pulse
}

void print_distance_with_tim(UART_HandleTypeDef huart){
	if (pulse_width_us != 0) {
		char tim_str[45];
		uint8_t distance=0;
		distance = (pulse_width_us/2) / 29.1;
	    sprintf(tim_str,"Pulse duration = %lu us\r\nDistance = %u\r\n", pulse_width_us,distance);
	    send_uart_message(huart,tim_str);
	    pulse_width_us = 0; // reset for next
	}
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
    {
        if (is_first_captured == 0)
        {
        	ic_val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
            is_first_captured = 1;
            //__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
        }
        else if (is_first_captured == 1)
        {
            ic_val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
            uint32_t captured;
            if (ic_val2 > ic_val1)
                captured = ic_val2 - ic_val1;
            else
                captured = (0xFFFFFFFF - ic_val1) + ic_val2;

            pulse_width_us = (captured + 40) / 80; // round to nearest // Since 1 tick = 1 µs
            is_first_captured = 0;

            // Reset to rising edge to prepare for next pulse
            //__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
        }
    }
}

void start_timer_ms(TIM_HandleTypeDef htim, uint32_t wait_time_ms)
{
	uint32_t ticks = wait_time_ms * 2; 			// 0.5ms per tick
    if (ticks>MAX_TIMER_COUNT)
    {
    	send_uart_message(huart2, "max timer count is 32767, try smaller number\r\n");
    	__HAL_RCC_TIM6_CLK_DISABLE();	// Disable timer peripheral clock to save power
    }
    else
    {
    	__HAL_RCC_TIM6_CLK_ENABLE(); 				// Enable timer peripheral clock
    	__HAL_TIM_DISABLE(&htim);  					// Stop timer before reconfig
    	__HAL_TIM_CLEAR_FLAG(&htim, TIM_SR_UIF);   	// Clear update interrupt flag
		__HAL_TIM_SET_COUNTER(&htim, 0); 			// Reset counter
		__HAL_TIM_SET_AUTORELOAD(&htim, ticks - 1); // ARR = ticks - 1
		__HAL_TIM_CLEAR_FLAG(&htim, TIM_SR_UIF);   	// Clear update interrupt flag
		HAL_TIM_Base_Start_IT(&htim); // Start with interrupt
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
    {
        HAL_TIM_Base_Stop_IT(htim);		// Stop timer and disable interrupt
        __HAL_RCC_TIM6_CLK_DISABLE();	// Disable timer peripheral clock to save power
        send_uart_message(huart2,"--------- timer is done!-----------\r\n");
        get_in_stop_mode = 1;
        HAL_PWR_EnableBkUpAccess();
        HAL_RTCEx_BKUPWrite(&hrtc, BACKUP_REG_GET_IN_STOP_MODE, 1); // Set flag
        HAL_PWR_DisableBkUpAccess();  // Re-lock it
    }
}

