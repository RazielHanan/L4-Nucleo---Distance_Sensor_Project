#include "main.h"
#include "uart_handler.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

extern UART_HandleTypeDef huart2;
extern Uart_handler_args* uart2_args;


void init_uart_args(){
	uart2_args->uart_dma_old_pos = 0;
	uart2_args->incoming_msgs = 0;
}

void send_uart_message(UART_HandleTypeDef huart, char* msg_to_send){
	HAL_UART_Transmit(&huart, (uint8_t*)msg_to_send, strlen(msg_to_send), 200);
}

void UART_DMA_Circular_Start(UART_HandleTypeDef huart)
{
    HAL_UART_Receive_DMA(&huart, uart2_args->uart_dma_buf, UART_DMA_BUF_SIZE);
    __HAL_UART_ENABLE_IT(&huart, UART_IT_IDLE);
}

void UART_DMA_Check_IDLE(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        uint16_t dma_curr_pos = UART_DMA_BUF_SIZE - __HAL_DMA_GET_COUNTER(huart->hdmarx);
        uint16_t bytes_to_process;

        if (dma_curr_pos >= uart2_args->uart_dma_old_pos)
        {
            bytes_to_process = dma_curr_pos - uart2_args->uart_dma_old_pos;
            memcpy(uart2_args->message_buf, &uart2_args->uart_dma_buf[uart2_args->uart_dma_old_pos], bytes_to_process);
        }
        else
        {
            // Wrap around case
            bytes_to_process = UART_DMA_BUF_SIZE - uart2_args->uart_dma_old_pos;
            memcpy(uart2_args->message_buf, &uart2_args->uart_dma_buf[uart2_args->uart_dma_old_pos], bytes_to_process);

            memcpy(&uart2_args->message_buf[bytes_to_process], &uart2_args->uart_dma_buf[0], dma_curr_pos);
            bytes_to_process += dma_curr_pos;
        }

        uart2_args->uart_dma_old_pos = dma_curr_pos;

        // Now search for '\r' or \n
        for (int i = 0; i < bytes_to_process; i++)
        {
            if (uart2_args->message_buf[i] == '\r' || uart2_args->message_buf[i] == '\n')
            {
            	uart2_args->message_buf[i++] = '\r';
            	uart2_args->message_buf[i++] = '\n';
            	uart2_args->message_buf[i] = '\0'; // Terminate string
            	send_uart_message(*huart, uart2_args->message_buf);  // Or handle message
            	uart2_args->incoming_msgs++;
                break;
            }
        }
    }
}


