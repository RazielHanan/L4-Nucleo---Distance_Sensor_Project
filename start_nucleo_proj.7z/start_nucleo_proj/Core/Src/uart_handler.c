#include "main.h"
#include "uart_handler.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
extern UART_HandleTypeDef huart2;



void init_uart_args(Uart_handler_args* uart){
	uart->idx = 0;
	uart->message_ready = 0;
	uart->message_just_completed = 0;
}

void get_rx_uart(UART_HandleTypeDef huart,char* msg){
	char error_msg[] = "UART RECEIVE TIMEOUT\r\n";
	char rx_buffer[64];
	uint8_t rx_byte = 0;
	size_t idx = 0;
	while(rx_byte!='\r' && rx_byte!='\n'){
		if(HAL_UART_Receive(&huart, &rx_byte, 1, 500) != HAL_OK){
		    // Timeout or error occurred, handle or break
			HAL_UART_Transmit(&huart, (uint8_t*)error_msg, strlen(error_msg), 200);
		    break; // or break;
		}
		rx_buffer[idx] = rx_byte;
		idx++;
	}

	if (rx_byte=='\r' || rx_byte=='\n'){
	    // Flush until line ends (\n), to clean up
	    while (HAL_UART_Receive(&huart, &rx_byte, 1, 200) == HAL_OK){};
		idx--;
		rx_buffer[idx++]='\r';
		rx_buffer[idx++]='\n';
		rx_buffer[idx]='\0';
		strcpy(msg,rx_buffer);
		HAL_UART_Transmit(&huart, (uint8_t*)msg, strlen(msg), 200);
	}
}

void send_uart_message(UART_HandleTypeDef huart, char* msg_to_send){
	HAL_UART_Transmit(&huart, (uint8_t*)msg_to_send, strlen(msg_to_send), 200);
}

uint8_t send_uart_with_counter(UART_HandleTypeDef huart,char* msg_to_send, uint8_t count){
	char msg[18];
	count++;
	if (count==256){
		count = 0;
	}
	send_uart_message(huart,msg_to_send);
	sprintf(msg,"msg_count: %u\r\n",count);
	if (HAL_UART_Transmit(&huart, (uint8_t*)msg, strlen(msg), 100) != HAL_OK){
		return 0;
	}

	return count;
}

bool get_uart_msgs(UART_HandleTypeDef huart, Uart_handler_args* uart){
	if (uart->message_ready) {  // when message is ready, handle it.
		send_uart_message(huart,uart->rx_buffer);
		free(uart->rx_buffer);
		uart->message_ready = 0;
		uart->rx_buffer = malloc(1);  // Reset to minimal buffer
		uart->rx_buffer[0] = '\0';
		return true;
	}
	return false;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
    if (huart->Instance == USART2)  // adjust if you're using a different UART
    {
        if (uart_args->message_just_completed && (uart_args->rx_temp == '\r' || uart_args->rx_temp == '\n')) {
        	uart_args->message_just_completed = 0;  // skip repeated newline
        }
        else if (uart_args->rx_temp == '\r' || uart_args->rx_temp == '\n') {
            if (uart_args->rx_buffer != NULL) {
            	char* temp = realloc(uart_args->rx_buffer, uart_args->idx + 3);
            	uart_args->rx_buffer = temp;
            	uart_args->rx_buffer[uart_args->idx] = '\r';
            	uart_args->rx_buffer[uart_args->idx+1] = '\n';
            	uart_args->rx_buffer[uart_args->idx+2] = '\0';  // null-terminate
            	uart_args->message_ready = 1;
            	uart_args->idx = 0;
            	uart_args->message_just_completed = 1;
            }
        }
        else {
            // Resize buffer to hold new char + null terminator
            char* temp = realloc(uart_args->rx_buffer, uart_args->idx + 2);
            if (temp != NULL) {
            	uart_args->rx_buffer = temp;
            	uart_args->rx_buffer[uart_args->idx++] = uart_args->rx_temp;
            	uart_args->rx_buffer[uart_args->idx] = '\0';  // keep null-terminated
            } else {
                // allocation failed, reset state
                free(uart_args->rx_buffer);
                uart_args->rx_buffer = NULL;
                uart_args->idx = 0;
            }
        }

        // Schedule next byte reception
        HAL_UART_Receive_IT(&huart2, (uint8_t*)&uart_args->rx_temp, 1);
    }
}

