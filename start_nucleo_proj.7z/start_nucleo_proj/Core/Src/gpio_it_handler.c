#include "gpio_it_handler.h"
#include "power_mode.h"
#include "main.h"

extern volatile uint8_t wakeup_flag;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_13) {
        //HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);  // Toggle LED on button press
    	wakeup_flag = 1;
    }
}

uint32_t get_adc_value_mV(ADC_HandleTypeDef hadc){
	HAL_ADC_Start(&hadc);
	HAL_ADC_PollForConversion(&hadc, HAL_MAX_DELAY);
	uint32_t adc_val = HAL_ADC_GetValue(&hadc);
	uint32_t adc_mvoltage = (uint32_t)(1000*(((float)adc_val / 4095.0f) * 3.3f)); // Convert to voltage
	return adc_mvoltage;
}
