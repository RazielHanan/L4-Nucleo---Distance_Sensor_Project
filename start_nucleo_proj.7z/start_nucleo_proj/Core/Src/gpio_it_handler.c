#include "gpio_it_handler.h"
#include "power_mode.h"
#include "main.h"
#include "uart_handler.h"
#include "stm32l4xx_hal.h"
#include <stdint.h>

#define VREFINT_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFF75AA)) // Factory calibrated VREFINT value at 3.0V
#define ADC_CHANNEL_VREFINT ADC_CHANNEL_VREFINT
#define ADC_TIMEOUT 100

extern UART_HandleTypeDef huart2;

extern volatile uint8_t wakeup_flag;



void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_13) {
        //HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);  // Toggle LED on button press
    	wakeup_flag = 1;
    }
}

uint32_t get_adc_value_mV(ADC_HandleTypeDef hadc){
	ADC_ChannelConfTypeDef sConfig = {0};
	sConfig.Channel = ADC_CHANNEL_1;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
	sConfig.SingleDiff = ADC_SINGLE_ENDED;
	sConfig.OffsetNumber = ADC_OFFSET_NONE;
	sConfig.Offset = 0;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	HAL_ADC_Start(&hadc);
	HAL_ADC_PollForConversion(&hadc, HAL_MAX_DELAY);
	uint32_t adc_val = HAL_ADC_GetValue(&hadc);
	HAL_ADC_Stop(&hadc);
	uint32_t adc_mvoltage = (uint32_t)(1000*(((float)adc_val / 4095.0f) * 3.3f)); // Convert to voltage
	return adc_mvoltage;
}

uint32_t get_vrefint_mv(ADC_HandleTypeDef* hadc){
		HAL_ADC_Start(hadc);
		HAL_ADC_PollForConversion(hadc, ADC_TIMEOUT);
		uint32_t adc_val = HAL_ADC_GetValue(hadc);
		HAL_ADC_Stop(hadc);
		uint16_t vrefint_cal = *VREFINT_CAL_ADDR;
		uint32_t vref_mv = (uint32_t)vrefint_cal * 1000 * 3.0f / (uint32_t)adc_val;  // Assuming factory cal was at 3.0V
		return vref_mv;
}


// Returns temperature in millidegrees Celsius (mdegC)
uint32_t read_internal_temp_mdegC(ADC_HandleTypeDef* hadc, uint32_t vrefint_mv) {
	char debug_str[120];
    // Enable temperature sensor and VREFINT
	ADC123_COMMON->CCR |= ADC_CCR_TSEN | ADC_CCR_VREFEN;

    // Configure ADC channel for temperature sensor
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = ADC_CHANNEL_TEMPSENSOR;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5; // Max sample time recommended
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;

    if (HAL_ADC_ConfigChannel(hadc, &sConfig) != HAL_OK) {
        // Handle error (optional)
        return INT32_MIN;  // Indicate error
    }

    // Start ADC conversion
    HAL_ADC_Start(hadc);
    HAL_Delay(50);
    if (HAL_ADC_PollForConversion(hadc, HAL_MAX_DELAY) != HAL_OK) {
        // Conversion error
        HAL_ADC_Stop(hadc);
        return 0;
    }
    HAL_ADC_Stop(hadc);
    uint32_t adc_val_raw = HAL_ADC_GetValue(hadc);
    //float adc_val = (uint32_t)(((float)adc_val_raw / 4095.0f) * 3.3f);

    // Read calibration values from system memory (factory calibrated values)
    const uint16_t* ts_cal1_addr = (uint16_t*)0x1FFF75A8; // TS_CAL1 @ 30°C
    const uint16_t* ts_cal2_addr = (uint16_t*)0x1FFF75CA; // TS_CAL2 @ 110°C
    uint16_t ts_cal1 = *ts_cal1_addr;
    uint16_t ts_cal2 = *ts_cal2_addr;

    const int32_t TS_CAL1_TEMP = 30;  // °C
    const int32_t TS_CAL2_TEMP = 110; // °C
//    sprintf(debug_str,"TS_CAL1 = %u\r\nTS_CAL2 = %u\r\nTS_CAL1_TEMP = %u\r\nTS_CAL2_TEMP = %u\r\n",
//    		ts_cal1,ts_cal2,TS_CAL1_TEMP,TS_CAL2_TEMP);
//    send_uart_message(huart2,debug_str);
    // Calculate temperature in millidegrees Celsius (mdegC)
    int32_t stage1=(1000*(TS_CAL2_TEMP-TS_CAL1_TEMP))/(ts_cal2-ts_cal1);
    int32_t stage2 = (int32_t)((int32_t)(adc_val_raw*vrefint_mv)/3000)-ts_cal1;
    uint32_t temperature_mdegC =(uint32_t)(((int32_t)stage1*stage2) + (int32_t)1000*TS_CAL1_TEMP);
    uint32_t temperature_degC = temperature_mdegC/1000;
//    sprintf(debug_str,"ADC_RAW: %u\r\n",adc_val_raw);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"ADC_ADJ: %u\r\n",adc_val);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"ts_cal1: %u\r\n",ts_cal1);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"ts_cal2: %u\r\n",ts_cal2);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"TS_CAL1_TEMP: %u\r\n",TS_CAL1_TEMP);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"TS_CAL2_TEMP: %u\r\n",TS_CAL2_TEMP);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"stage1 = %d\r\n",stage1);
//    send_uart_message(huart2,debug_str);
//    sprintf(debug_str,"stage2 = %d\r\n",stage2);
//    send_uart_message(huart2,debug_str);
    sprintf(debug_str,"temperature_degC = %u Deg\r\n -----------------\r\n",temperature_degC);
    send_uart_message(huart2,debug_str);
    return temperature_degC;
}





