#include "power_mode.h"
#include "uart_handler.h"
#include "main.h"
#include <stdlib.h>

extern ADC_HandleTypeDef hadc3;
extern DAC_HandleTypeDef hdac1;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim6;
extern UART_HandleTypeDef huart2;
extern DMA_HandleTypeDef hdma_usart2_rx;

extern Uart_handler_args* uart2_args;

//extern volatile uint8_t wakeup_flag;

void set_all_gpio_to_analog(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /*Configure GPIO pin : B1_Pin */
    GPIO_InitStruct.Pin = B1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

    /*Configure GPIO pin : LD2_Pin */
    GPIO_InitStruct.Pin = LD2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

    /*Configure GPIO pin : PA8 */
    GPIO_InitStruct.Pin = GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /*
    // Configure all pins to analog with no pull
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Pin = GPIO_PIN_All;

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();

    // Set all GPIOs to analog
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);
    */
    // Reconfigure PC13 (user button) as interrupt input with no pull
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

void shutdown_all_peripherals(void)
{

    // --- UART & DMA ---
	free(uart2_args);
    HAL_UART_DMAStop(&huart2);
    HAL_UART_DeInit(&huart2);
    HAL_DMA_DeInit(&hdma_usart2_rx);
    HAL_NVIC_DisableIRQ(USART2_IRQn);
    HAL_NVIC_DisableIRQ(DMA1_Channel6_IRQn);
    //__HAL_RCC_DMA1_CLK_DISABLE();
    //__HAL_RCC_USART2_CLK_DISABLE();

    // --- TIMERS ---
    //HAL_TIM_Base_Stop_IT(&htim6);
    HAL_TIM_Base_DeInit(&htim6);
    HAL_NVIC_DisableIRQ(TIM6_DAC_IRQn);
    //__HAL_RCC_TIM6_CLK_DISABLE();

    //HAL_TIM_IC_Stop_IT(&htim2, TIM_CHANNEL_1);
    HAL_TIM_IC_DeInit(&htim2);
    HAL_NVIC_DisableIRQ(TIM2_IRQn);
    //__HAL_RCC_TIM2_CLK_DISABLE();


    HAL_TIM_PWM_DeInit(&htim1);
    //HAL_NVIC_DisableIRQ(TIM1_CC_IRQn);
    //__HAL_RCC_TIM1_CLK_DISABLE();

    // --- DAC ---
    HAL_DAC_DeInit(&hdac1);
    HAL_DAC_Stop(&hdac1, DAC_CHANNEL_1);
    //__HAL_RCC_DAC1_CLK_DISABLE();

    // --- ADC ---
    HAL_ADC_DeInit(&hadc3);
    HAL_NVIC_DisableIRQ(ADC3_IRQn);  // If used
    //__HAL_RCC_ADC_CLK_DISABLE();

    // --- GPIOs to analog, except PC13 ---
    set_all_gpio_to_analog();

    // --- Keep button EXTI (e.g., PC13) interrupt enabled for wakeup
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);  // Don't disable if used to wake up

    HAL_SuspendTick(); // optional, to stop SysTick
}

void init_peripherals(void){
	UART_DMA_Circular_Start(huart2);

	//start_timer_ms(htim6, 5000); // put this line to enter again to stop mode.

	HAL_DAC_Start(&hdac1, DAC_CHANNEL_1);
    uint32_t vref = 3300; // mV
	uint32_t target_voltage_mv = 1900; // this is supply 1.5V on the adc.
	uint32_t dac_max = 4095;
	uint32_t dac_val = (target_voltage_mv * dac_max) / vref;
	HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_val);

	HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
}
/*
void wakeup_from_shutdown(void)
{
	//if (wakeup_flag){
		wakeup_flag = 0;

		// --- RCC Clocks ---
		__HAL_RCC_GPIOA_CLK_ENABLE();
		__HAL_RCC_GPIOB_CLK_ENABLE();
		__HAL_RCC_GPIOC_CLK_ENABLE();
		__HAL_RCC_GPIOH_CLK_ENABLE();
		__HAL_RCC_DMA1_CLK_ENABLE();
		__HAL_RCC_USART2_CLK_ENABLE();
		__HAL_RCC_TIM6_CLK_ENABLE();
		__HAL_RCC_TIM2_CLK_ENABLE();
		__HAL_RCC_TIM1_CLK_ENABLE();
		__HAL_RCC_ADC_CLK_ENABLE();
		__HAL_RCC_DAC1_CLK_ENABLE();

		// --- Init peripherals ---
		MX_GPIO_Init();
		MX_DMA_Init();
		MX_USART2_UART_Init();
		MX_ADC3_Init();
		MX_DAC1_Init();
		MX_TIM2_Init();
		MX_TIM1_Init();
		MX_TIM6_Init();

		// --- Enable IRQs ---
		HAL_NVIC_EnableIRQ(USART2_IRQn);
		HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);
		HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
		HAL_NVIC_EnableIRQ(TIM2_IRQn);
		HAL_NVIC_EnableIRQ(TIM1_CC_IRQn);
		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);  // For button wake-up
		// HAL_NVIC_EnableIRQ(ADC3_IRQn);  // If used
		uart2_args = (Uart_handler_args*) malloc(sizeof(Uart_handler_args));
		init_uart_args(uart2_args);
		init_peripherals();
	//}

}
*/

